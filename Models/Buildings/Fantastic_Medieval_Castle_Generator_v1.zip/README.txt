                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1612651
Fantastic Medieval Castle Generator v1 by Zivbot is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

**Try the new [Grand Castle Generator](http://www.thingiverse.com/thing:1682427), less controls and more unique results.**

This customizer code generates countless varieties of castles with plenty of customizable controls. Read on for some tips and guidelines.

If you're new to the Customizer concept, start by hitting the "Open in Customizer" button on the right panel. After you play around with the settings and like what you see, click "Create Thing" to have it generated (takes a while) as an STL file you can download.

You'll be able to control the basic elements for a respectable castle:
- Building (main structure)
- Towers (ground rooted, sorrounding the building)
- Turrets (recursively sorrounding towers / turrets)
- Island (of course...)

When you start out, most settings are set to random and changing the "random seed" value will mix everything. You can start taming your own castle by moving settings away from "0" or "Random" to specific values.

Keep the details OFF for quickly trying different structures, and turn the details on when you're ready to generate. For non-trivial castles you may get "script time-out" in the preview if you have details on, but they might still generate successfully.

Overall dimensions are affected by several settings, so its easiest to generate what you like and then scale it inside your printing software.

The model is meant to allow for printing without supports (45 deg rule).

Before you click "Create Thing"
--------------------------------------
- When you click "Create Thing" your model goes into a production QUEUE and you get to choose "email me when its done". Do it.
- Producing the model with details could take a long time, and may even fail, since Thingiverse limits the generation to 1h. So you might want to first generate your castle without details, stay in the same window ("return to customizer"), and put another generate _with_ details. This way at least you'll always have the simpler version.
- If you're printing at a small scale (<4cm height?) or low resolution, you may want to forego details completely.

"Partial Generation" Feature: With this feature you can produce separate STLs for Roofs, Island and structures. This is currently good for rendering (e.g. KeyShot). 
It's not optimized for multi-material printing, but if you give it a try let me know.


Finally, I've been itching to make a castle generator ever since visiting Neuschwanstein almost a decade ago, and got reinspired by the brilliant http://www.thingiverse.com/thing:862724

Enjoy!

Write below with suggestions, requests and complaints - I'll try to deliver on future versions.

Those of you into OpenSCAD are invited to develop it further. I've tried to make it clear and useful, and there are some basic algorithms (like for distributing the windows) you may find useful in other projects.
Its up on github: https://github.com/zivbot/castle



# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator 2
Rafts: No
Supports: No
Infill: 10%

Notes: 
I've printed a simple version so far (shown), at 75% scale. Normal settings. No special issues. It won me "father of the year".