                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1682427
Grand Castle Generator by Zivbot is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**Now updated with some bug fixes and an ISLAND generator - see below **

This customizer generates vartiations of fortresses and castles, simple to complex, with simple friendly controls.

If you're new to the Customizer concept, start by hitting the "Open in Customizer" button on the right panel. After you play around with the settings and like what you see, click "Create Thing" to have it generated (takes a while) as an STL file you can download and print.

In this code I'm attempting to combine the best of the two previous generators:
[Recursive turrets](http://www.thingiverse.com/thing:1612651)
[Perimiter wall with towers](http://www.thingiverse.com/thing:1639567)
But instead of 30+ controls, you now have only 9.
This means less specific control, but the ability to explore a large variety quickly.

### ISLAND GENERATOR
Play around with the **island-random-seed** for different formations and sizes, or set it to 0 for no island.
This brilliant addition is courtesy of [Torleif](http://www.thingiverse.com/Torleif/about) whose [own generators](http://www.thingiverse.com/Torleif/designs/page:2) are mind blowing (seriously, its the real thing). Check it out if you know whats good for you.



# This is how it works

![Alt text](https://cdn.thingiverse.com/assets/07/0d/e3/1c/5f/Castle-Anim-Interface.gif)