                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3024153
Planttlement - Castle Planter with Moat, for Succulents by Cutlass is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

The Planttlement is designed to fit a medium sized succulent in the main body and one smaller plant in the turret.

I have added small alligators to guard the moat of the Planttlement by using this model:  https://www.thingiverse.com/thing:373168


The bottom of the castle is designed with a slight slope to help with drainage and has 5 small sized drain holes to drain excess water into the moat surrounding the base. The turret has a single drain hole which drains into the main body of the castle.

Modeled in Solidworks, and printed on a standard Prusa MK2. Supports are not needed and it was designed to be completely unsupported. I printed it using simplify 3D, though it will work with any slicer.

# Print Settings

Printer Brand: Prusa
Printer: Prusa Mk2
Rafts: No
Supports: No
Resolution: 0.1-0.2mm
Infill: Doesn't Matter

Notes: 
Due to the size of this print using a larger layer height is recommended. The largest tested is a 0.2 mm later height.  The bricks should resolve up to a 0.4 mm layer height but this is untested.