                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2917515
Predator Action Pliers by ecoiras is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Having managed to learn the basics of Fusion360 I wanted to do some kind of grabtoy, similar to the ones I made with OpenSCAD. A key requisite was to design the thing so that it could be printed without supports and already assembled in place, ready to use right from the printer bed.

I had this memory of a very cool ice cube push plunger claw tongs my parents used to have, and initially tried to go in that direction. Something I wanted to change though was the push-to-open action into push-to-close, because you kind of close the hand when you push, right? So that was another requirement for the design.

I ended up with this overcomplicated geared approach to the thing, and after seeing it in action it reminded me of the mouth of that alien in the movie "Predator", so I decided to call it Predator Action Pliers. For building the gears I used the Helical Gear Generator by [Gear_Down_For_What](https://www.thingiverse.com/Gear_Down_For_What).

The thing looks mean but its grip is actually not very strong. In fact as a grabbing tool is not very useful at all. Still, it prints-in-place without supports and it closes when you push, so I think the design specifications have been met, making the project a great success.

Enjoy!

**EDIT:** There is a new version of this thing: [Predator Action Pliers Mk2](https://www.thingiverse.com/thing:2949649)

**EDIT2:** Ok, so you still prefer this *classique* version anyway. If that's the case you probably want to print the **PredatorActionPliers--more_grip.stl** upgrade, which does a better job at grabbing stuff

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 20%

Notes: 
Printed in PLA