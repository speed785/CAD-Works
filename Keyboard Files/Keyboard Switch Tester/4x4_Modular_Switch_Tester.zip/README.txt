                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2620977
4x4 Modular Switch Tester by Biccins is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

**The 4x4 is not finalized - please keep this in mind when printing and please leave feedback :) 

This is a 4x4 switch tester that will hold up to 16 switches per switch plate. There are four parts in the download section that can make the tester as large or as small as you'd like. The parts are as follows:

- Switch Plate (Holds 16 switches with legs at the bottom)
- Switch Plate with Walls (Holds 16 switches with walls around the base instead of legs)
- Top Cover (Encloses the top of the 4x4 switch tester)
- Bottom Cover (Encloses the bottom of the 4x4 switch tester)


<b>PLEASE NOTE:</b> Scale down the item x10 when you import it into your slicer.


Enjoy! Please post pictures of your final outcome and suggest updates to the design. Also leave ideas for future projects!