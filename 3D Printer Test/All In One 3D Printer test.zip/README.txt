                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2656594
All In One 3D Printer test by majda107 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Are you suffering from issue and can't find any way to fix it?!
Be sure to checkout guide specified to this model, <b>guide isn't complete yet (23.8.2018) but there are some cool tweaks you should definitelly know!</b>
https://3dnation504795197.wordpress.com/guide/
Here is link for those people, who wan't to support me, it won't cost you any money, only 5 seconds of your time. So If you want to support me (without any fees), go to the guide this way! <b>Thanks <3</b>
http://zipansion.com/3C9Yh

Here is even newer, better, smaller and more compact 3D printer test!
https://www.thingiverse.com/thing:2975429

NOTE: Checkout new MINI version of this 3D printer test! 
https://www.thingiverse.com/thing:2806295


!UPDATE! (25.02.2018 1:28 CZ time)
- I was notified (big thanks to Craven112) about one small issue with my 3D design so I decided to fix it! The issue was "0.5mm diameter" text, which was meant to be "1.0mm diameter" text. Also, the hole test got a little mistake, the "8mm" hole was actually 9 mm in the diameter. Now everything should be fixed in "3D printer test fixed (3nd gen).stl" file. 

- I've also changed rotation of the model, so now it should be in the correct position :-).

----------------------------------------------------------------------------------------------------------------------

I decided to design All In One 3D Printer test, so here it is. This test includes : support test, scale test, overhang test, hole test, diameter test and bridging test. Print this with 100% Infill without supports.

!NOTE! : If you are using Cura and you are experiencing missing text issue, be sure to enable "use thin wall" setting! (big thanks to CoreyNach for this!)

We've just got over 5k likes border, THANK YOU ALL!!!!

 If you like me design, feel free to tip me :-)