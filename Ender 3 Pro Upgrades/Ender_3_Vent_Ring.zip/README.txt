                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2912394
Ender 3 Vent Ring by Filboyt is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

New Version available Here - https://www.thingiverse.com/thing:3343456

Designed a Vent Ring that also directs some of the wasted Wind from Hot-End's fan.
Wanted a full Circle that was Unique, 
Forced air in certain areas for faster print speeds,
Would not send anything towards the Nozzle,
Redirected the Hot-End airflow that goes low.
This is the Surviving design.

You may need to Loosen the screws of your hot end fan housing to level this out.
many come from factory just slapped together and not adjusted. It's a $200 printer with
great parts. Please don't over-tighten this into your fan.

The original version that works best on early Ender-3's.
Short is  for more clearance from bed

I have thinned the screw mounts on short 2 for the newer Ender-3's that have short screws
.stp file of Short Version has been included

For those who have tipped me a coffee, I offer back a huge thanks.
For those who wish to, I drink the cheap stuff. 

# Print Settings

Printer: Creality Ender 3
Rafts: No
Supports: No
Resolution: .1 to .14 Only!
Infill: Any