                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2989218
Drawer for Ender3, Ender 3 by Jaypirnts is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

THIS IS "NOT" SUITABLE FOR ENDER3 PRO USERS.

------------------------------------------------------------------------

※ Zig-zaging
If your nozle diameter is 0.4mm, set your extusion width 0.45mm to avoid zig-zaging behavoir on wall construction and reduce overall print time.

------------------------------------------------------------------------

just a simple top sealed drawer with V-slot for ender3 machine.
test printed and it is good to go.
have fun printing^^

Screen Cover for Ender 3 : https://www.thingiverse.com/thing:2978734
Spool Holder for Ender 3: https://www.thingiverse.com/thing:2999446


https://www.youtube.com/watch?v=nXvWsQGOkPw

# Print Settings

Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: 0.2
Infill: 20%
Filament_brand: any
Filament_material: PLA