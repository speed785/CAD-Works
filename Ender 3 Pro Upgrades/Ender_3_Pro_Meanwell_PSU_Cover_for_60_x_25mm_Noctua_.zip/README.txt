                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3515458
Ender 3 Pro Meanwell PSU Cover for 60 x 25mm Noctua  by ford_jake is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Remix of https://www.thingiverse.com/thing:3484372 ; Fixed screw hole sizing, model imperfections, adjust the height of the bottom so it will actually fit the PSU. Added Corner Support to the bottom. 

I have printed this twice and it came out great.

Uses this fan : https://www.amazon.com/Noctua-60x25mm-Blades-Bearing-Premium/dp/B009NQMESS

Note PSU Fan is 12v not 24v like the rest of the machine.

# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: Yes
Resolution: .2
Infill: 10%
Filament_brand: Hatchbox
Filament_color: Red and Gold
Filament_material: PLA